import React from "react";
import Signup from "./components/Signup";
import Signin from "./components/Signin";

function App() {
  return (
    <div>
      <h1>Spotify Clone</h1>
      <Signup />
      <Signin />
    </div>
  );
}

export default App;
